﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace CoverShooter
{
	[ExecuteInEditMode]
	public class GrenadeBar : MonoBehaviour, IPointerDownHandler, IEventSystemHandler
	{
		[Tooltip("Motor which will be assigned to use grenades when pressed.")]
		public CharacterMotor Motor;

		[Tooltip("Determines if the ammo bar is hidden when there is no target.")]
		public bool HideWhenNone;

		[Tooltip("Link to the object that draws the background of the ammo bar.")]
		public RectTransform BackgroundRect;

		[Tooltip("Link to the icon object.")]
		public RectTransform Icon;

		[Tooltip("Link to the object that will be used to display a gun's name.")]
		public Text Name;

		public Text Ammo;

		[Tooltip("Color to use on elements when the gun is selected.")]
		public Color ActiveColor = Color.white;

		[Tooltip("Color to use on elements when the gun is not selected.")]
		public Color InactiveColor = new Color(1f, 1f, 1f, 0.6f);


        public void Start()
        {
			Motor.Grenade.Ammo = 5;

		}
        public void OnPointerDown(PointerEventData eventData)
		{
			if (Motor != null && Motor.Grenade.Ammo > 0)
			{
				if (!Motor.HasGrenadeInHand)
				{
					Motor.InputTakeGrenade();
				}
				else
				{
					Motor.InputCancelGrenade();
				}
			}
		}

		private void LateUpdate()
		{
			if (Application.isPlaying)
			{
				if (Motor != null)
				{
					Ammo.text = $"{Motor.Grenade.Ammo}";
				}
				bool isVisible = !HideWhenNone || Motor != null;
				updateElement(BackgroundRect, isVisible);
				updateElement(Icon, isVisible);
				updateElement(Name, isVisible);
				updateElement(Ammo, isVisible);
			}
		}

		private void updateElement(RectTransform obj, bool isVisible)
		{
			if (obj == null)
			{
				return;
			}
			if (obj.gameObject.activeSelf != isVisible)
			{
				obj.gameObject.SetActive(isVisible);
			}
			if (isVisible)
			{
				Image component = obj.GetComponent<Image>();
				if (Motor != null)
				{
					component.color = ((!Motor.HasGrenadeInHand) ? InactiveColor : ActiveColor);
				}
			}
		}

		private void updateElement(Text obj, bool isVisible)
		{
			if (!(obj == null) && obj.gameObject.activeSelf != isVisible)
			{
				obj.gameObject.SetActive(isVisible);
			}
		}
	}
}
