﻿using UnityEngine;

namespace CoverShooter
{
    /// <summary>
    /// Stops all actions and tells the characters to move back to default positions.
    /// </summary>
    public class RegroupBTN : PressButton
    {
        /// <summary>
        /// Character switcher whose active character is managed.
        /// </summary>
        public CharacterMotor motor;
        protected override void OnPress()
        {   
                    motor.SendMessage("ToStopActions", SendMessageOptions.DontRequireReceiver);
                    motor.SendMessage("ToRegroupFormation");
                }
            }
        
    
}
